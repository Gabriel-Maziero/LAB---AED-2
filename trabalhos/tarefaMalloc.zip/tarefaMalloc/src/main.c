#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "../include/include.h"

int main(int argc, char const *argv[])
{
    char nomeArquivos[50];
    int arquivos = 1;
    int tmp, leituraarq = 2;
    float *vetAux;
    Aluno **alunos;
    FILE *fp = fopen(argv[1], "r+");
    FILE *arquivo = fopen("../../saidas/relatorioDeOrdenacao.txt", "w");
    //FILE *ArqCsvs = fopen("../../saidas/relatorioTempoExecucao.csv", "w+");
    for (int i = 0; i < 5; i++)
    {
        sprintf(nomeArquivos, "../../saidas/relatorio%d.csv", arquivos);
        FILE *criarArquivoCsv = fopen(nomeArquivos, "w");
        arquivos++;
        for (int j = 0; j < 11; j++)
        {
            char converter[50];
            leituraarq *= 2;
            sprintf(converter, "../../entradas/alunos_%d.csv", leituraarq);
            FILE *leituraArqCsv = fopen(converter, "r");
            tmp = alocAluno(leituraArqCsv);
            vetAux = (float *)malloc(tmp * sizeof(float));
            TempoDeProcessamento(tmp, &vetAux, criarArquivoCsv, leituraArqCsv);
            fclose(leituraArqCsv);
            free(vetAux);
        } // Le todos os .csv em uma execução, e libera a memoria utilizada
        fclose(criarArquivoCsv);
    }
    if (argc == 1)
        fp = fopen("../../notas.csv", "r+");
    if (fp == NULL)
    {
        perror("Error opening file");
        exit(1);
    }
    tmp = alocAluno(fp);
    exemplo_leitura_linha(fp, arquivo, tmp, &alunos);
    vetAux = (float *)malloc(tmp * sizeof(float));
    Ordenacao(arquivo, &alunos, tmp, &vetAux);
    for (int i = 0; i < tmp; i++)
    {
        free(alunos[i]->notas);
        free(alunos[i]);
    }
    free(alunos);
    fclose(fp);
    fclose(arquivo);
   // fclose(ArqCsvs);
    return 0;
}
