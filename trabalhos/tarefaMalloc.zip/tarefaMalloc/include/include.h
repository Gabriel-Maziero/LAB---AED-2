#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <Windows.h>
typedef struct
{
    char nome[50];
    float *notas;
    float mediaAlunos;
    int num_notas;
} Aluno;

int alocAluno(FILE *fp)
{
    char buffer[256];
    int tmp = 0;
    while (fgets(buffer, sizeof(buffer), fp) != NULL)
    {
        tmp++;
    }
    return tmp;
}
/**
 * @brief Esta função vai ler o notas.csv la do main, e receber como parametros as vars do main, não confundir,
 * Faz parte das tarefas passadas.
 */
void exemplo_leitura_linha(FILE *fp, FILE *arquivo, int tmp, Aluno ***alunos)
{
    char linha[256], linha2[256];
    rewind(fp);
    *alunos = (Aluno **)malloc(tmp * sizeof(Aluno *));
    for (int i = 0; i < tmp; i++)
        (*alunos)[i] = (Aluno *)malloc(sizeof(Aluno));
    int i = 0;
    // Tenta ler uma linha do arquivo. Se for bem-sucedido...
    while (fgets(linha, sizeof(linha), fp) != NULL)
    {
        strcpy(linha2, linha);
        char *token;
        // Primeiro, tokeniza a linha usando a vírgula como delimitador
        token = strtok(linha, ",");
        if (token != NULL)
            strcpy((*alunos)[i]->nome, token); // Copia o 1 token, no caso o nome para o campo nome da struct do aluno

        int notas = 0;
        float res = 0.0;
        char *temp = strtok(NULL, ","); // Pega a primeira nota, 2 token
        while (temp != NULL)            // Caso houver uma nota, != NULL
        {
            notas++;                  // computa a nota
            temp = strtok(NULL, ","); // Pega o proximo token, nota
        }
        (*alunos)[i]->notas = (float *)malloc(notas * sizeof(float));
        (*alunos)[i]->num_notas = notas;
        // Pega o proximo token
        strtok(linha2, ",");
        for (int j = 0; j < notas; j++)
        {
            token = strtok(NULL, ",");
            (*alunos)[i]->notas[j] = atof(token);
            res += (*alunos)[i]->notas[j];
        }
        fprintf(arquivo, "Nome do aluno: %s , ", (*alunos)[i]->nome);
        for (int k = 0; k < notas; k++)
            fprintf(arquivo, "nota %d : %.2f ", k + 1, (*alunos)[i]->notas[k]);
        fprintf(arquivo, " e media do aluno: %.2f \n", res / (*alunos)[i]->num_notas);
        (*alunos)[i]->mediaAlunos = res / (*alunos)[i]->num_notas;
        i++;
    }
}

void BubbleSort(Aluno ***alunos, int quantAlunos)
{
    float aux;
    for (int i = 1; i < quantAlunos; i++)
    {
        for (int j = 0; j < quantAlunos - i; j++)
        {
            if ((*alunos)[j]->mediaAlunos < (*alunos)[j + 1]->mediaAlunos)
            {
                aux = (*alunos)[j]->mediaAlunos;
                (*alunos)[j]->mediaAlunos = (*alunos)[j + 1]->mediaAlunos;
                (*alunos)[j + 1]->mediaAlunos = aux;
                // Sleep(0.5);
            }
        }
    }
}

void Ordenacao(FILE *arquivo, Aluno ***alunos, int quantAlunos, float **vetorAux)
{
    int indice[quantAlunos];
    for (int i = 0; i < quantAlunos; i++)
        (*vetorAux)[i] = (*alunos)[i]->mediaAlunos;

    BubbleSort(alunos, quantAlunos);

    for (int i = 0; i < quantAlunos; i++)
    {
        for (int j = 0; j < quantAlunos; j++)
        {
            if ((*alunos)[i]->mediaAlunos == (*vetorAux)[j])
                indice[i] = j;
        }
    }
    fprintf(arquivo, "\n\n");
    fprintf(arquivo, "Medias ordenadas: \n\n");
    for (int i = 0; i < quantAlunos; i++)
    {
        fprintf(arquivo, "Nome do aluno: %s , ", (*alunos)[indice[i]]->nome);
        for (int k = 0; k < (*alunos)[i]->num_notas; k++)
            fprintf(arquivo, "nota %d : %.2f ", k + 1, (*alunos)[indice[i]]->notas[k]);
        fprintf(arquivo, " e media do aluno: %.2f \n", (*alunos)[i]->mediaAlunos);
    }
}

/**
 * @brief Esta função é chamada no TempodeProcessamento, que é chamado com novos parametros a cada interação la no main
 * ou seja, ela ficara alterando os valores,
 */
void leituraLinhasCsv(FILE *ArqsCsv, Aluno ***vetorAlunos, int quantAlunos)
{
    char linha[256], linha2[256];
    rewind(ArqsCsv);
    int i = 0;
    // Tenta ler uma linha do arquivo. Se for bem-sucedido...
    while (fgets(linha, sizeof(linha), ArqsCsv) != NULL)
    {
        strcpy(linha2, linha);
        char *token;
        // Primeiro, tokeniza a linha usando a vírgula como delimitador
        token = strtok(linha, ",");
        if (token != NULL)
            strcpy((*vetorAlunos)[i]->nome, token); // Copia o 1 token, no caso o nome para o campo nome da struct do aluno

        int notas = 0;
        float res = 0.0;
        char *temp = strtok(NULL, ","); // Pega a primeira nota, 2 token
        while (temp != NULL)            // Caso houver uma nota, != NULL
        {
            notas++;                  // computa a nota
            temp = strtok(NULL, ","); // Pega o proximo token, nota
        }
        (*vetorAlunos)[i]->notas = (float *)malloc(notas * sizeof(float));
        (*vetorAlunos)[i]->num_notas = notas;
        // Pega o proximo token
        strtok(linha2, ",");
        for (int j = 0; j < notas; j++)
        {
            token = strtok(NULL, ",");
            (*vetorAlunos)[i]->notas[j] = atof(token);
            res += (*vetorAlunos)[i]->notas[j];
        }
        (*vetorAlunos)[i]->mediaAlunos = res / (*vetorAlunos)[i]->num_notas;
        i++;
    }
    for (int i = 0; i < quantAlunos; i++)
        free((*vetorAlunos)[i]->notas);
}

void QuickSort(Aluno ***alunos, int inicio, int fim)
{
    int pivo = (inicio + fim) / 2, esquerda = inicio, direita = fim;
    float aux;
    while (esquerda <= direita)
    {
        while ((*alunos)[esquerda]->mediaAlunos > (*alunos)[pivo]->mediaAlunos)
            esquerda++;
        while ((*alunos)[direita]->mediaAlunos < (*alunos)[pivo]->mediaAlunos)
            direita--;
        if (esquerda <= direita)
        {
            aux = (*alunos)[esquerda]->mediaAlunos;
            (*alunos)[esquerda]->mediaAlunos = (*alunos)[direita]->mediaAlunos;
            (*alunos)[direita]->mediaAlunos = aux;
            //Sleep(0.5);
            esquerda++;
            direita--;
        }
    }
    // SubVetor 1
    if (esquerda < fim)
        QuickSort(alunos, esquerda, fim);

    // SubVetor2
    if (inicio < direita)
        QuickSort(alunos, inicio, direita);
}

void merge(Aluno ***vetorAlunos, int inicio, int meio, int fim)
{
    int n1 = meio - inicio + 1;
    int n2 = fim - meio;

    // Vetores temporários
    float *esq = (float *)malloc(n1 * sizeof(float));
    float *dir = (float *)malloc(n2 * sizeof(float));

    // Copia os elementos para os vetores auxiliares
    for (int i = 0; i < n1; i++)
        esq[i] = (*vetorAlunos)[inicio + i]->mediaAlunos;
    for (int j = 0; j < n2; j++)
        dir[j] = (*vetorAlunos)[meio + 1 + j]->mediaAlunos;

    int i = 0, j = 0, k = inicio;

    // Intercala de volta no vetor original
    while (i < n1 && j < n2)
    {
        if (esq[i] <= dir[j])
        {
            (*vetorAlunos)[k]->mediaAlunos = esq[i];
            i++;
        }
        else
        {
            (*vetorAlunos)[k]->mediaAlunos = dir[j];
            j++;
        }
        k++;
    }

    // Copia os elementos restantes (se houver)
    while (i < n1)
    {
        (*vetorAlunos)[k]->mediaAlunos = esq[i];
        // Sleep(0.5);
        i++;
        k++;
    }

    while (j < n2)
    {
        (*vetorAlunos)[k]->mediaAlunos = dir[j];
        // Sleep(0.5);
        j++;
        k++;
    }

    // Libera memória
    free(esq);
    free(dir);
}

// Função recursiva do Merge Sort
void mergeSort(Aluno ***vetorAlunos, int inicio, int fim)
{
    if (inicio < fim)
    {
        int meio = inicio + (fim - inicio) / 2;

        // Ordena a primeira e segunda metade
        mergeSort(vetorAlunos, inicio, meio);
        mergeSort(vetorAlunos, meio + 1, fim);

        // Intercala as duas metades
        merge(vetorAlunos, inicio, meio, fim);
    }
}

void TempoDeProcessamento(int quantAlunos, float **vetorAux, FILE *ArqCsv, FILE *lerArquivosCsv)
{
    double tempo[3];
    clock_t inicio;
    clock_t fim;
    Aluno **vetorAlunos = (Aluno **)malloc(quantAlunos * sizeof(Aluno *));
    for (int i = 0; i < quantAlunos; i++)
        vetorAlunos[i] = (Aluno *)malloc(sizeof(Aluno));

    leituraLinhasCsv(lerArquivosCsv, &vetorAlunos, quantAlunos); // Leitura das medias

    for (int i = 0; i < quantAlunos; i++)
        (*vetorAux)[i] = vetorAlunos[i]->mediaAlunos;

    // Para desordenar o vetor, para que no proximo arquivo maior,o vetor esteja desordenado

    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < quantAlunos; j++)
            vetorAlunos[j]->mediaAlunos = (*vetorAux)[j]; // Desordenar para o proximo alg

        switch (i)
        {
        case 0:
            inicio = clock();

            BubbleSort(&vetorAlunos, quantAlunos);

            fim = clock();

            tempo[i] = (double)(fim - inicio) / CLOCKS_PER_SEC;

            break;
        case 1:
            inicio = clock();

            QuickSort(&vetorAlunos, 0, quantAlunos - 1);

            fim = clock();

            tempo[i] = (double)(fim - inicio) / CLOCKS_PER_SEC;
            break;
        default:
            inicio = clock();

            mergeSort(&vetorAlunos, 0, quantAlunos - 1);
            fim = clock();

            tempo[i] = (double)(fim - inicio) / CLOCKS_PER_SEC;
            break;
        }
    }
    fprintf(ArqCsv, "Tamanho dos dados: %d , tempo do QuickSort: %.20f , tempo do MergeSort: %.20f , tempo do BubbleSort: %.20f \n",
            quantAlunos, tempo[1], tempo[2], tempo[0]);
    for (int i = 0; i < quantAlunos; i++)
        free(vetorAlunos[i]);
    free(vetorAlunos); // Libera a memoria a cada chamada da função, lendo e escrevendo 1 linha para cada .csv e liberando a memoria
}
