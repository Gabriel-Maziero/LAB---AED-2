#include <stdio.h>
#include <stdlib.h>

typedef struct
{
    char nome[30];
    char autor[30];
    int ano;
} Filme;

typedef struct No
{
    Filme dado;
    struct No *proximo;
} No;

// 2. Definição da Estrutura da Lista Ligada
typedef struct
{
    No *comeco;  // Ponteiro para o primeiro nó da lista (HEAD)
    int tamanho; // Tamanho da lista (opcional)
} Lista;

void cria_lista(Lista *lista);

int lista_vazia(Lista lista);

int inserir_no_comeco(Lista *lista, Filme f);

int remove_no_comeco(Lista *lista, Filme *f);

int inserir_no_indice(Lista *lista, Filme f, int i);

int inserir_ordenado_ano(Lista *lista, Filme f);

void cria_lista(Lista *lista)
{
    lista->comeco = NULL;
    lista->tamanho = 0;
}

int lista_vazia(Lista lista)
{
    if (lista.comeco == NULL)
        return 1;
    return 0;
}

int inserir_no_comeco(Lista *lista, Filme f)
{
    No *novo = (No *)malloc(sizeof(No));
    if (novo == NULL)
        return 0; // Falha na alocação de memória

    novo->dado = f;                // Atribui o filme ao novo nó
    novo->proximo = lista->comeco; // Novo nó aponta para o antigo primeiro nó
    lista->comeco = novo;          // Atualiza o início da lista para o novo nó
    lista->tamanho++;              // Incrementa o tamanho da lista
    return 1;                      // Sucesso
}

int remove_no_comeco(Lista *lista, Filme *f)
{
    if (lista_vazia(*lista))
        return 0; // Lista vazia, nada a remover

    No *temp = lista->comeco;               // Armazena o nó a ser removido
    *f = temp->dado;                        // Copia o dado do nó removido para o filme fornecido
    lista->comeco = lista->comeco->proximo; // Atualiza o início da lista
    free(temp);                             // Libera a memória do nó removido
    lista->tamanho--;                       // Decrementa o tamanho da lista
    return 1;                               // Sucesso
}

int inserir_no_indice(Lista *lista, Filme f, int i)
{
    No *elem = (No *)malloc(sizeof(No));
    No *aux = lista->comeco;
    int auxint = 0;
    if (elem == NULL)
        return 0;
    elem->dado = f;
    printf("%s\n", elem->dado.nome);
    if(i == 0)
    {
        elem->proximo = lista->comeco;
        lista->comeco = elem;
    }
    while (auxint != i)
    {
        if (aux->proximo != NULL)
        {
            if (auxint == i)
            {
                elem->proximo = aux->proximo;
                aux->proximo = elem;
            }
            aux = aux->proximo;
            auxint++;
        }
        if (aux->proximo == NULL)
        {
            aux->proximo = elem;
            elem->proximo = NULL;
        }
    }
    lista->tamanho++;
}

int inserir_ordenado_ano(Lista *lista, Filme f)
{
    No *elem = (No *)malloc(sizeof(No));
    No *aux = lista->comeco;
    if (lista_vazia(*lista))
        return 0;
    elem->dado = f;    
    if (elem->dado.ano < lista->comeco->dado.ano)
    {
        elem->proximo = lista->comeco;
        lista->comeco = elem;
        return 1;
    }
    while (aux->proximo != NULL)
    {
        if(aux->proximo->dado.ano > elem->dado.ano)
        {
            elem->proximo = aux->proximo;
            aux->proximo = elem;
        }
        aux = aux->proximo;
    }
    
    lista->tamanho++;
    return 1;
}
